# -*- coding: utf-8 -*-

default_app_config = 'test_app.apps.TestAppConfig'
